<?
$arModuleVersion = array(
    "VERSION" => "1.0.8",
    "VERSION_DATE" => "2023-06-12 12:13:00"
);