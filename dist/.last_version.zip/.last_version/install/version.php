<?
$arModuleVersion = array(
    "VERSION" => "1.0.3",
    "VERSION_DATE" => "2022-11-09 21:00:00"
);