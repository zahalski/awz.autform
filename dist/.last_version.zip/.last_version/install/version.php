<?
$arModuleVersion = array(
    "VERSION" => "1.0.6",
    "VERSION_DATE" => "2022-12-26 13:24:00"
);