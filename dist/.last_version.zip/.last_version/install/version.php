<?
$arModuleVersion = array(
    "VERSION" => "1.0.5",
    "VERSION_DATE" => "2022-12-12 13:19:00"
);