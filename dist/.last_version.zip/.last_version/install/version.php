<?
$arModuleVersion = array(
    "VERSION" => "1.0.4",
    "VERSION_DATE" => "2022-11-11 00:06:00"
);